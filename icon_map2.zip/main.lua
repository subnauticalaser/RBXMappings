function Create(ty,data)
	local obj
	if type(ty) == 'string' then
		obj = Instance.new(ty)
	else
		obj = ty
	end
	for k, v in pairs(data) do
		if type(k) == 'number' then
			v.Parent = obj
		else
			obj[k] = v
		end
	end
	return obj
end



---- IconMap ----
-- Image size: 256px x 256px
-- Icon size: 16px x 16px
-- Padding between each icon: 2px
-- Padding around image edge: 1px
-- Total icons: 14 x 14 (196)
local Icon do
	local iconMap = 'rbxassetid://79000652950119'
	-- game:GetService('ContentProvider'):Preload(iconMap)
	local iconDehash do
		-- 14 x 14, 0-based input, 0-based output
		local f=math.floor
		function iconDehash(h)
			return f(h/14%14),f(h%14)
		end
	end

	function Icon(IconFrame,index)
		local row,col = iconDehash(index)
		local mapSize = Vector2.new(256,256)
		local pad,border = 2,1
		local iconSize = 16

		local class = 'Frame'
		if type(IconFrame) == 'string' then
			class = IconFrame
			IconFrame = nil
		end

		if not IconFrame then
			IconFrame = Create(class,{
				Name = "Icon";
				BackgroundTransparency = 1;
				ClipsDescendants = true;
				Create('ImageLabel',{
					Name = "IconMap";
					Active = false;
					BackgroundTransparency = 1;
					Image = iconMap;
					Size = UDim2.new(mapSize.x/iconSize,0,mapSize.y/iconSize,0);
				});
			})
		end

		IconFrame.IconMap.Position = UDim2.new(-col - (pad*(col+1) + border)/iconSize,0,-row - (pad*(row+1) + border)/iconSize,0)
		return IconFrame
	end
end




local Mappings = {
	[1] = {
		['CoreGui'] = 0,  -- Row 0, Col 0
		['Enum'] = 1,  -- Row 0, Col 1
		['EnumMember'] = 2,  -- Row 0, Col 2
		['EqualizerSoundEffect'] = 3,  -- Row 0, Col 3
		['Event'] = 4,  -- Row 0, Col 4
		['Explosion'] = 5,  -- Row 0, Col 5
		['FaceControls'] = 6,  -- Row 0, Col 6
		['Field'] = 7,  -- Row 0, Col 7
		['File'] = 8,  -- Row 0, Col 8
		['Fire'] = 9,  -- Row 0, Col 9
		['FlangeSoundEffect'] = 10,  -- Row 0, Col 10
		['Folder'] = 11,  -- Row 0, Col 11
		['ForceField'] = 12,  -- Row 0, Col 12
		['Frame'] = 13,  -- Row 0, Col 13
		['Function'] = 14,  -- Row 1, Col 0
		['GameSettings'] = 15,  -- Row 1, Col 1
		['GroundController'] = 16,  -- Row 1, Col 2
		['Handles'] = 17,  -- Row 1, Col 3
		['HapticService'] = 18,  -- Row 1, Col 4
		['HeightmapImporterService'] = 19,  -- Row 1, Col 5
		['Highlight'] = 20,  -- Row 1, Col 6
		['HingeConstraint'] = 21,  -- Row 1, Col 7
		['Humanoid'] = 22,  -- Row 1, Col 8
		['HumanoidDescription'] = 23,  -- Row 1, Col 9
		['IKControl'] = 24,  -- Row 1, Col 10
		['ImageButton'] = 25,  -- Row 1, Col 11
		['ImageHandleAdornment'] = 26,  -- Row 1, Col 12
		['ImageLabel'] = 27,  -- Row 1, Col 13
		['Interface'] = 28,  -- Row 2, Col 0
		['IntersectOperation'] = 29,  -- Row 2, Col 1
		['Keyword'] = 30,  -- Row 2, Col 2
		['Lighting'] = 31,  -- Row 2, Col 3
		['LineForce'] = 32,  -- Row 2, Col 4
		['LineHandleAdornment'] = 33,  -- Row 2, Col 5
		['LinearVelocity'] = 34,  -- Row 2, Col 6
		['LocalFile'] = 35,  -- Row 2, Col 7
		['LocalScript'] = 36,  -- Row 2, Col 8
		['LocalizationService'] = 37,  -- Row 2, Col 9
		['LocalizationTable'] = 38,  -- Row 2, Col 10
		['MaterialService'] = 39,  -- Row 2, Col 11
		['MaterialVariant'] = 40,  -- Row 2, Col 12
		['MemoryStoreService'] = 41,  -- Row 2, Col 13
		['MeshPart'] = 42,  -- Row 3, Col 0
		['Meshparts'] = 43,  -- Row 3, Col 1
		['MessagingService'] = 44,  -- Row 3, Col 2
		['Method'] = 45,  -- Row 3, Col 3
		['Model'] = 46,  -- Row 3, Col 4
		['Modelgroups'] = 47,  -- Row 3, Col 5
		['Module'] = 48,  -- Row 3, Col 6
		['ModuleScript'] = 49,  -- Row 3, Col 7
		['Motor6D'] = 50,  -- Row 3, Col 8
		['NegateOperation'] = 51,  -- Row 3, Col 9
		['NetworkClient'] = 52,  -- Row 3, Col 10
		['NoCollisionConstraint'] = 53,  -- Row 3, Col 11
		['Operator'] = 54,  -- Row 3, Col 12
		['Pants'] = 55,  -- Row 3, Col 13
		['Part'] = 56,  -- Row 4, Col 0
		['ParticleEmitter'] = 57,  -- Row 4, Col 1
		['Path2D'] = 58,  -- Row 4, Col 2
		['PathfindingLink'] = 59,  -- Row 4, Col 3
		['PathfindingModifier'] = 60,  -- Row 4, Col 4
		['PathfindingService'] = 61,  -- Row 4, Col 5
		['PitchShiftSoundEffect'] = 62,  -- Row 4, Col 6
		['Place'] = 63,  -- Row 4, Col 7
		['Plane'] = 64,  -- Row 4, Col 8
		['PlaneConstraint'] = 65,  -- Row 4, Col 9
		['Player'] = 66,  -- Row 4, Col 10
		['Players'] = 67,  -- Row 4, Col 11
		['PluginGuiService'] = 68,  -- Row 4, Col 12
		['PointLight'] = 69,  -- Row 4, Col 13
		['PrismaticConstraint'] = 70,  -- Row 5, Col 0
		['Property'] = 71,  -- Row 5, Col 1
		['ProximityPrompt'] = 72,  -- Row 5, Col 2
		['PublishService'] = 73,  -- Row 5, Col 3
		['Reference'] = 74,  -- Row 5, Col 4
		['RemoteEvent'] = 75,  -- Row 5, Col 5
		['RemoteFunction'] = 76,  -- Row 5, Col 6
		['RenderingTest'] = 77,  -- Row 5, Col 7
		['ReplicatedFirst'] = 78,  -- Row 5, Col 8
		['ReplicatedScriptService'] = 79,  -- Row 5, Col 9
		['ReplicatedStorage'] = 80,  -- Row 5, Col 10
		['ReverbSoundEffect'] = 81,  -- Row 5, Col 11
		['RigidConstraint'] = 82,  -- Row 5, Col 12
		['RobloxPluginGuiService'] = 83,  -- Row 5, Col 13
		['RocketPropulsion'] = 84,  -- Row 6, Col 0
		['RodConstraint'] = 85,  -- Row 6, Col 1
		['RopeConstraint'] = 86,  -- Row 6, Col 2
		['Rotate'] = 87,  -- Row 6, Col 3
		['ScreenGui'] = 88,  -- Row 6, Col 4
		['Script'] = 89,  -- Row 6, Col 5
		['ScrollingFrame'] = 90,  -- Row 6, Col 6
		['Seat'] = 91,  -- Row 6, Col 7
		['Selected_Workspace'] = 92,  -- Row 6, Col 8
		['SelectionBox'] = 93,  -- Row 6, Col 9
		['SelectionSphere'] = 94,  -- Row 6, Col 10
		['ServerScriptService'] = 95,  -- Row 6, Col 11
		['ServerStorage'] = 96,  -- Row 6, Col 12
		['Service'] = 97,  -- Row 6, Col 13
		['Shirt'] = 98,  -- Row 7, Col 0
		['ShirtGraphic'] = 99,  -- Row 7, Col 1
		['SkinnedMeshPart'] = 100,  -- Row 7, Col 2
		['Sky'] = 101,  -- Row 7, Col 3
		['Smoke'] = 102,  -- Row 7, Col 4
		['Snap'] = 103,  -- Row 7, Col 5
		['Snippet'] = 104,  -- Row 7, Col 6
		['SocialService'] = 105,  -- Row 7, Col 7
		['Sound'] = 106,  -- Row 7, Col 8
		['SoundEffect'] = 107,  -- Row 7, Col 9
		['SoundGroup'] = 108,  -- Row 7, Col 10
		['SoundService'] = 109,  -- Row 7, Col 11
		['Sparkles'] = 110,  -- Row 7, Col 12
		['SpawnLocation'] = 111,  -- Row 7, Col 13
		['SpecialMesh'] = 112,  -- Row 8, Col 0
		['SphereHandleAdornment'] = 113,  -- Row 8, Col 1
		['SpotLight'] = 114,  -- Row 8, Col 2
		['SpringConstraint'] = 115,  -- Row 8, Col 3
		['StandalonePluginScripts'] = 116,  -- Row 8, Col 4
		['StarterCharacterScripts'] = 117,  -- Row 8, Col 5
		['StarterGui'] = 118,  -- Row 8, Col 6
		['StarterPack'] = 119,  -- Row 8, Col 7
		['StarterPlayer'] = 120,  -- Row 8, Col 8
		['StarterPlayerScripts'] = 121,  -- Row 8, Col 9
		['Struct'] = 122,  -- Row 8, Col 10
		['StyleDerive'] = 123,  -- Row 8, Col 11
		['StyleLink'] = 124,  -- Row 8, Col 12
		['StyleRule'] = 125,  -- Row 8, Col 13
		['StyleSheet'] = 126,  -- Row 9, Col 0
		['SunRaysEffect'] = 127,  -- Row 9, Col 1
		['SurfaceAppearance'] = 128,  -- Row 9, Col 2
		['SurfaceGui'] = 129,  -- Row 9, Col 3
		['SurfaceLight'] = 130,  -- Row 9, Col 4
		['SurfaceSelection'] = 131,  -- Row 9, Col 5
		['SwimController'] = 132,  -- Row 9, Col 6
		['TaskScheduler'] = 133,  -- Row 9, Col 7
		['Team'] = 134,  -- Row 9, Col 8
		['Teams'] = 135,  -- Row 9, Col 9
		['Terrain'] = 136,  -- Row 9, Col 10
		['TerrainDetail'] = 137,  -- Row 9, Col 11
		['TestService'] = 138,  -- Row 9, Col 12
		['TextBox'] = 139,  -- Row 9, Col 13
		['TextBoxService'] = 140,  -- Row 10, Col 0
		['TextButton'] = 141,  -- Row 10, Col 1
		['TextChannel'] = 142,  -- Row 10, Col 2
		['TextChatCommand'] = 143,  -- Row 10, Col 3
		['TextChatService'] = 144,  -- Row 10, Col 4
		['TextLabel'] = 145,  -- Row 10, Col 5
		['TextString'] = 146,  -- Row 10, Col 6
		['Texture'] = 147,  -- Row 10, Col 7
		['Tool'] = 148,  -- Row 10, Col 8
		['Torque'] = 149,  -- Row 10, Col 9
		['TorsionSpringConstraint'] = 150,  -- Row 10, Col 10
		['Trail'] = 151,  -- Row 10, Col 11
		['TremoloSoundEffect'] = 152,  -- Row 10, Col 12
		['TrussPart'] = 153,  -- Row 10, Col 13
		['TypeParameter'] = 154,  -- Row 11, Col 0
		['UGCValidationService'] = 155,  -- Row 11, Col 1
		['UIAspectRatioConstraint'] = 156,  -- Row 11, Col 2
		['UICorner'] = 157,  -- Row 11, Col 3
		['UIDragDetector'] = 158,  -- Row 11, Col 4
		['UIFlexItem'] = 159,  -- Row 11, Col 5
		['UIGradient'] = 160,  -- Row 11, Col 6
		['UIGridLayout'] = 161,  -- Row 11, Col 7
		['UIListLayout'] = 162,  -- Row 11, Col 8
		['UIPadding'] = 163,  -- Row 11, Col 9
		['UIPageLayout'] = 164,  -- Row 11, Col 10
		['UIScale'] = 165,  -- Row 11, Col 11
		['UISizeConstraint'] = 166,  -- Row 11, Col 12
		['UIStroke'] = 167,  -- Row 11, Col 13
		['UITableLayout'] = 168,  -- Row 12, Col 0
		['UITextSizeConstraint'] = 169,  -- Row 12, Col 1
		['UnionOperation'] = 170,  -- Row 12, Col 2
		['Unit'] = 171,  -- Row 12, Col 3
		['UniversalConstraint'] = 172,  -- Row 12, Col 4
		['UnreliableRemoteEvent'] = 173,  -- Row 12, Col 5
		['UpdateAvailable'] = 174,  -- Row 12, Col 6
		['UserService'] = 175,  -- Row 12, Col 7
		['VRService'] = 176,  -- Row 12, Col 8
		['Value'] = 177,  -- Row 12, Col 9
		['Variable'] = 178,  -- Row 12, Col 10
		['VectorForce'] = 179,  -- Row 12, Col 11
		['VehicleSeat'] = 180,  -- Row 12, Col 12
		['VideoFrame'] = 181,  -- Row 12, Col 13
		['VideoPlayer'] = 182,  -- Row 13, Col 0
		['ViewportFrame'] = 183,  -- Row 13, Col 1
		['VirtualUser'] = 184,  -- Row 13, Col 2
		['VoiceChannel'] = 185,  -- Row 13, Col 3
		['VoiceChatService'] = 186,  -- Row 13, Col 4
		['Voicechat'] = 187,  -- Row 13, Col 5
		['WedgePart'] = 188,  -- Row 13, Col 6
		['Weld'] = 189,  -- Row 13, Col 7
		['WeldConstraint'] = 190,  -- Row 13, Col 8
		['Wire'] = 191,  -- Row 13, Col 9
		['WireframeHandleAdornment'] = 192,  -- Row 13, Col 10
		['Workspace'] = 193,  -- Row 13, Col 11
		['WorldModel'] = 194,  -- Row 13, Col 12
		['WrapLayer'] = 195,  -- Row 13, Col 13
	}
};





--[[
for i, v in pairs(game:GetChildren()) do
	local a = pcall(function()
		local icon = Icon(nil, Mappings[1][v.ClassName])
		icon.Parent = script.Parent
		icon.Size = UDim2.new(0, 16, 0, 16)
		
		print(v.ClassName .. ' is added!')
	end)
	
	
	if not a then
		print('Missing: ' .. tostring(v.ClassName))
	end
end
]]



local icon = Icon(nil, 14*14)
icon.Parent = script.Parent
icon.Size = UDim2.new(0, 16, 0, 16)
