from PIL import Image
import os

def create_icon_map(input_folder, output_file):
    # Configuration
    image_size = 256  # Size of the final image
    icon_size = 16    # Size of each icon
    padding = 2       # Padding between icons
    edge_padding = 1  # Padding around the image edge
    icons_per_row = 14

    # Create a blank image with the specified dimensions
    canvas = Image.new("RGBA", (image_size, image_size), (0, 0, 0, 0))

    # Get the list of icon files in the folder
    icons = [f for f in os.listdir(input_folder) if f.lower().endswith('.png')]

    # Sort the icons to ensure consistent ordering
    icons.sort()

    # Initialize the Lua mapping and other variables
    lua_mapping = "local Mappings = {\n    [1] = {\n"
    index = 0  # Sequential index (starting from 0)
    x_offset = edge_padding
    y_offset = edge_padding

    for icon_file in icons:
        # Load the icon image
        icon_path = os.path.join(input_folder, icon_file)
        icon = Image.open(icon_path).convert("RGBA")

        # Resize the icon to the desired size (if necessary)
        icon = icon.resize((icon_size, icon_size), Image.Resampling.LANCZOS)

        # Paste the icon onto the canvas
        canvas.paste(icon, (x_offset, y_offset), mask=icon)

        # Calculate row and column
        row = index // icons_per_row
        col = index % icons_per_row

        # Extract the name of the icon without the extension
        icon_name = os.path.splitext(icon_file)[0]

        # Add to Lua mapping
        lua_mapping += f"        ['{icon_name}'] = {index},  -- Row {row}, Col {col}\n"

        # Update the position for the next icon
        x_offset += icon_size + padding
        if (index + 1) % icons_per_row == 0:
            x_offset = edge_padding
            y_offset += icon_size + padding

        # Stop if we've filled the grid
        if y_offset + icon_size + edge_padding > image_size:
            break

        # Increment the index
        index += 1

    # Close the Lua mapping
    lua_mapping += "    }\n};\n"

    # Save the final image
    canvas.save(output_file)

    # Save and print the Lua table
    lua_output_file = os.path.splitext(output_file)[0] + "_mappings.lua"
    with open(lua_output_file, "w") as lua_file:
        lua_file.write(lua_mapping)
    print(f"Icon map saved as {output_file}")
    print(f"Lua mapping saved as {lua_output_file}")
    print(lua_mapping)

# Usage example
input_folder = "C:/Users/JulianAlexanderNorba/Downloads/Roblox Icons into 1/16x16/Images"  # Replace with your folder path containing 16x16 PNGs
output_file = "icon_map.png"     # Output file name
create_icon_map(input_folder, output_file)
